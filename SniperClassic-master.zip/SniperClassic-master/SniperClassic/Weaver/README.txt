cmd line :

Unity.UNetWeaver.exe 
"UnityEngine.CoreModule.dll" absolute or relative path
"UnityEngine.Networking.dll" absolute or relative path
"Patched/" folder where it end up
"DebugToolkit.dll" ass to patch
"DebugToolkitRepo/libs/" ass dependencies
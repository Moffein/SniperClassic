﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SniperClassic.Hooks
{
    public class WeakPointHook
    {
        public WeakPointHook()
        {
            //todo: Create new VFX that the same as Weakpoint VFX but with a different sound.
            //todo: Convert weakpoint bonus from crit to +50% damage if ModdedDamageType SniperClassicDamage is present.
        }
    }
}

﻿namespace SniperClassic.Modules
{
    public class Survivors
    {

    }
}
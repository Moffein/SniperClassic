﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntityStates.SniperClassicSkills
{
    class ReloadSuperShotgun : ReloadSnipe
    {
    }
}

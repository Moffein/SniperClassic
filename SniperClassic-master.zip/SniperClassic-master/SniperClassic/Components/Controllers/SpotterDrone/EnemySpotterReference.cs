﻿using UnityEngine;
using RoR2;

namespace SniperClassic
{
    public class EnemySpotterReference : MonoBehaviour
    {
        public GameObject spotterOwner;
    }
}
﻿using RoR2;
using UnityEngine;

namespace SniperClassic
{
    public class MasterScopeStateComponent : MonoBehaviour
    {
        public float storedFOV;
    }
}
